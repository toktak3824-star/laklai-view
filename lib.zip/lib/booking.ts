import { supabase } from "./supabase";

export async function createBooking(data: any) {
  const { data: booking, error } = await supabase
    .from("bookings")
    .insert([data])
    .select()
    .single();

  if (error) {
    console.error("BOOKING ERROR =", error);
    throw error;
  }

  console.log("BOOKING SUCCESS");

  return booking;
}