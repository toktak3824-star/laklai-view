import { supabase } from "./supabase";

export async function uploadSlip(file: File) {
  const fileName = `${Date.now()}-${file.name}`;

  const { error } = await supabase.storage
  .from("payment-slips")
  .upload(fileName, file);

if (error) {
  console.error(error);
  throw error;
}

  const { data } = supabase.storage
    .from("payment-slips")
    .getPublicUrl(fileName);

  return data.publicUrl;
}