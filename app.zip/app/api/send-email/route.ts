import { Resend } from "resend";
import { NextResponse } from "next/server";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    const {
  email,
  guestName,
  roomName,
  checkIn,
  checkOut,
  totalPrice,
  bookingCode,
} = await req.json();

  await resend.emails.send({
      from: "Laklai View <booking@laklaiview.com>",
      to: email,
      subject: "ยืนยันการได้รับคำขอจอง Laklai View",
      html: `
        <h2>ขอบคุณสำหรับการจอง</h2>

        <p>สวัสดี คุณ <b>${guestName}</b></p>

        <p>เราได้รับคำขอจองของคุณเรียบร้อยแล้ว</p>

        <hr/>

        <p><b>เลขที่การจอง</b> : ${bookingCode}</p>
        <p><b>บ้านพัก</b> : ${roomName}</p>
        <p><b>เช็คอิน</b> : ${checkIn}</p>
        <p><b>เช็คเอาท์</b> : ${checkOut}</p>
        <p><b>ยอดชำระ</b> : ฿${Number(totalPrice).toLocaleString()}</p>

        <br/>

        <p>ขณะนี้สถานะของคุณคือ</p>

        <h3>รอตรวจสอบสลิปการโอน</h3>

        <br/>

        <p>เมื่อแอดมินตรวจสอบเรียบร้อยแล้ว
        ระบบจะส่งอีเมลยืนยันให้อัตโนมัติ</p>

        <br/>

        <p>ขอบคุณที่เลือกพักกับ Laklai View หลักลายวิว❤️</p>
      `,
    });

    await resend.emails.send({
  from: "Laklai View <booking@laklaiview.com>",
  to: "toktak3824@gmail.com", // อีเมลแอดมิน

  subject: "🔔 มีการจองใหม่",

  html: `
      <h2>มีลูกค้าจองเข้ามาใหม่</h2>

      <p><b>เลขที่การจอง</b> : ${bookingCode}</p>

      <p><b>ชื่อ</b> : ${guestName}</p>

      <p><b>บ้านพัก</b> : ${roomName}</p>

      <p><b>Check in</b> : ${checkIn}</p>

      <p><b>Check out</b> : ${checkOut}</p>

      <p><b>ยอดเงิน</b> : ฿${Number(totalPrice).toLocaleString()}</p>

      <br>

      <p>เข้าไปตรวจสอบในระบบแอดมินเพื่อยืนยันการจอง</p>
  `,
});

    return NextResponse.json({ success: true });

  } catch (err) {
    console.error("SEND EMAIL ERROR =", err);

return NextResponse.json(
  {
    error: "Email failed",
    detail: String(err),
  },
  { status: 500 }
);
  }
}