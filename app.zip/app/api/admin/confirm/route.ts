import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";

export async function POST(req: Request) {
  try {
    const { id } = await req.json();

    // ดึงข้อมูลการจองก่อน
    const { data: booking, error: bookingError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", id)
      .single();

    if (bookingError) {
      throw bookingError;
    }

    // อัปเดตสถานะ
    const { error } = await supabase
      .from("bookings")
      .update({
        booking_status: "confirmed",
        payment_status: "paid",
      })
      .eq("id", id);

    if (error) {
      throw error;
    }

    // ขั้นต่อไปเราจะส่งอีเมลตรงนี้

    return NextResponse.json({
      success: true,
      booking,
    });

  } catch (err) {
    console.error(err);

    return NextResponse.json(
      {
        error: "Confirm Failed",
      },
      {
        status: 500,
      }
    );
  }
}