type Props = {
  params: Promise<{
    bookingCode: string;
  }>;
};

export default async function PaymentPage({
  params,
}: Props) {

  const { bookingCode } = await params;
  return (
    <main className="mx-auto min-h-screen max-w-3xl p-8">

      <h1 className="mb-6 text-4xl font-bold text-stone-800">
        ชำระเงิน
      </h1>

      <div className="rounded-2xl bg-white p-8 shadow">

        <p className="text-lg">
          เลขที่การจอง
        </p>

        <p className="mt-2 text-3xl font-bold text-green-700">
          {bookingCode}
        </p>

      </div>

    </main>
  );
}