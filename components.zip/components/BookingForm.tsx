"use client";

import { calculatePrice } from "@/utils/calculatePrice";
import { uploadSlip } from "@/lib/uploadSlip";
import { useEffect, useMemo, useState } from "react";
import { createBooking } from "@/lib/booking";
import type { Room } from "@/types/room";

type Props = {
  room: Room;
};

export default function BookingForm({ room }: Props) {
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");

  const [adults, setAdults] = useState(room.defaultGuests);
  const [children, setChildren] = useState(0);

  const [extraBed, setExtraBed] = useState(false);

  const [guestName, setGuestName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  const [slip, setSlip] = useState<File | null>(null);

  const [acceptPolicy, setAcceptPolicy] = useState(false);

  const [isHoliday, setIsHoliday] = useState(false);

  useEffect(() => {
    if (!checkIn) return;

    const day = new Date(checkIn).getDay();

    setIsHoliday(day === 0 || day === 6);
  }, [checkIn]);

  const bookingResult = useMemo(() => {
  if (!checkIn || !checkOut) {
    return null;
  }

  return calculatePrice(room, {
    checkIn: new Date(checkIn),
    checkOut: new Date(checkOut),
    adults,
    children,
    extraChildBed: extraBed,
  });
}, [
  room,
  checkIn,
  checkOut,
  adults,
  children,
  extraBed,
]);

const totalPrice = bookingResult?.grandTotal ?? 0;

    return (
    <div className="space-y-6 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">

      <div>
        <h2 className="text-2xl font-bold text-stone-800">
          จองที่พัก
        </h2>

        <p className="mt-1 text-sm text-stone-500">
          กรุณากรอกข้อมูลให้ครบถ้วน
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">

        <div>
          <label className="mb-2 block text-sm font-medium text-stone-700">
            วันเข้าพัก
          </label>

          <input
            type="date"
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
            className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium text-stone-700">
            วันออก
          </label>

          <input
            type="date"
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
            className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black"
          />
        </div>

      </div>

      <div className="grid gap-4 md:grid-cols-2">

        <div>
          <label className="mb-2 block text-sm font-medium text-stone-700">
            จำนวนผู้ใหญ่
          </label>

          <select
            value={adults}
            onChange={(e) => setAdults(Number(e.target.value))}
            className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black placeholder:text-stone-400"
          >
            {Array.from(
              { length: room.maxGuests },
              (_, i) => i + 1
            ).map((n) => (
              <option key={n} value={n}>
                {n} คน
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium text-stone-700">
            เด็ก
          </label>

          <select
            value={children}
            onChange={(e) => setChildren(Number(e.target.value))}
            className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black placeholder:text-stone-400"
          >
            {[0,1,2].map((n)=>(
              <option key={n} value={n}>
                {n} คน
              </option>
            ))}
          </select>
        </div>

      </div>

      <div className="flex items-center gap-3">

        <input
          type="checkbox"
          checked={extraBed}
          onChange={(e)=>setExtraBed(e.target.checked)}
        />

        <span className="text-stone-700">
          เพิ่มเตียงเสริม
          (+{room.extraChildBedPrice.toLocaleString()} บาท)
        </span>

      </div>

      <div className="space-y-4">

        <input
          type="text"
          placeholder="ชื่อผู้จอง"
          value={guestName}
          onChange={(e)=>setGuestName(e.target.value)}
          className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black placeholder:text-stone-400"
        />
        <input
          type="email"
          placeholder="อีเมล"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black placeholder:text-stone-400"
        />
        <input
          type="tel"
          placeholder="เบอร์โทรศัพท์"
          value={phone}
          onChange={(e)=>setPhone(e.target.value)}
          className="w-full rounded-xl border border-stone-300 bg-white p-3 text-black placeholder:text-stone-400"
        />

      </div>

      <div>

  <div className="mb-4 rounded-xl border border-stone-300 bg-stone-50 p-4">

    <label className="flex items-start gap-3">

      <input
        type="checkbox"
        checked={acceptPolicy}
        onChange={(e) => setAcceptPolicy(e.target.checked)}
        className="mt-1"
      />

      <span className="text-sm text-stone-700">
        ข้าพเจ้าได้อ่านและยอมรับนโยบายการจอง การชำระเงิน และการยกเลิกของ Laklai View แล้ว
      </span>

    </label>

  </div>

  <label className="mb-2 block font-medium text-stone-700">
    แนบสลิปการโอน
  </label>

        <input
          type="file"
          accept="image/*"
          onChange={(e) => {
  const file = e.target.files?.[0] ?? null;

  console.log("เลือกไฟล์ =", file);

  setSlip(file);
}}
        />

      </div>

      <div className="rounded-xl bg-stone-100 p-5 space-y-2">

        <div className="flex justify-between">
  <span>ราคาปกติ</span>

  <span className="line-through text-gray-400">
    ฿{bookingResult?.roomTotal.toLocaleString() ?? 0}
  </span>
</div>

<div className="flex justify-between text-xl font-bold">
  <span>ราคาที่ต้องชำระ</span>

  <span className="text-green-700">
    <p>จำนวนคืน : {bookingResult?.nights}</p>

<p>ค่าห้อง : {bookingResult?.roomTotal}</p>

<p>รวมทั้งหมด : {bookingResult?.grandTotal}</p>
    ฿{totalPrice.toLocaleString()}
  </span>
</div>

      </div>
            <button
        type="button"
        className="w-full rounded-xl bg-green-700 py-4 text-lg font-semibold text-white transition hover:bg-green-800"
        onClick={async () => {

  if (!acceptPolicy) {
    alert("กรุณายอมรับนโยบายก่อนดำเนินการต่อ");
    return;
  }

  try {
    console.log({
      checkIn,
      checkOut,
    });

    let slipUrl = "";

if (!slip) {
  alert("กรุณาแนบสลิปการโอนเงินก่อนดำเนินการต่อ");
  return;
}

console.log("กำลังอัปโหลดสลิป...");

slipUrl = await uploadSlip(slip);

console.log("URL =", slipUrl);
const now = new Date();

const bookingCode =
  "LKV-" +
  now.getFullYear().toString().slice(-2) +
  String(now.getMonth() + 1).padStart(2, "0") +
  String(now.getDate()).padStart(2, "0") +
  "-" +
  Date.now().toString().slice(-4);

const booking = await createBooking({
  room_id: room.id,
  guest_name: guestName,
  email,
  phone,
  check_in: checkIn,
  check_out: checkOut,
  adults,
  children,
  total_price: totalPrice,

  booking_status: "pending",
  payment_status: "waiting",

  slip_url: slipUrl,

  booking_code: bookingCode,
});

console.log("บันทึกลงฐานข้อมูลแล้ว");

window.location.href = `/payment/${bookingCode}`;

  } catch (error) {
    console.error(error);
    alert("เกิดข้อผิดพลาด");
  }
}}
>
  ยืนยันการจอง
</button>

    </div>
  );
}