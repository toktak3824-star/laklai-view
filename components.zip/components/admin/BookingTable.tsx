"use client";

import { useEffect, useState } from "react";

export default function BookingTable() {
  const [bookings, setBookings] = useState<any[]>([]);

  useEffect(() => {
    loadBookings();
  }, []);

  async function loadBookings() {
    const res = await fetch("/api/admin/bookings");
    const data = await res.json();
    setBookings(data);
  }

  function roomName(roomId: string) {
    switch (roomId) {
      case "house1":
        return "บ้านสวนวิถี";
      case "house2":
        return "บ้านพักใจ";
      case "house3":
        return "บ้านแสงดาว";
      case "house4":
        return "บ้านสุขใจ";
      default:
        return roomId;
    }
  }

  return (
    <div className="mt-10 rounded-2xl bg-white p-6 shadow">

      <h2 className="mb-6 text-2xl font-bold text-stone-900">
        📋 รายการจองทั้งหมด
      </h2>

      <table className="w-full text-stone-800">

        <thead>

          <tr className="border-b">

            <th className="py-3 text-left">เลขจอง</th>

            <th className="text-left">ลูกค้า</th>

            <th className="text-left">บ้านพัก</th>

            <th className="text-left">วันที่</th>

            <th className="text-left">ยอดเงิน</th>

            <th className="text-left">สลิป</th>

            <th className="text-left">สถานะ</th>

          </tr>

        </thead>

        <tbody>

          {bookings.map((booking) => (

            <tr
              key={booking.id}
              className="border-b hover:bg-stone-50"
            >

              <td className="py-4 font-semibold">
                {booking.booking_code ?? "-"}
              </td>

              <td>
                {booking.guest_name}
              </td>

              <td>
                {roomName(booking.room_id)}
              </td>

              <td>
                {booking.check_in}
                <br />
                {booking.check_out}
              </td>

              <td>
                ฿{Number(booking.total_price).toLocaleString()}
              </td>

              <td>
  <a
    href={booking.slip_url}
    target="_blank"
    className="rounded bg-blue-600 px-3 py-2 text-white"
  >
    ดูสลิป
  </a>

</td>
              <td className="space-x-2">

  <button
    onClick={async () => {

      await fetch("/api/admin/confirm", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: booking.id,
        }),
      });

      loadBookings();

    }}
    className="rounded bg-green-600 px-3 py-2 text-white hover:bg-green-700"
  >
    อนุมัติ
  </button>

  <button
  onClick={async () => {

    await fetch("/api/admin/cancel", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: booking.id,
      }),
    });

    loadBookings();

  }}
  className="rounded bg-red-600 px-3 py-2 text-white hover:bg-red-700"
>
  ยกเลิก
</button>

  <span
    className={
      booking.booking_status === "confirmed"
        ? "rounded-full bg-green-100 px-3 py-1 text-sm font-semibold text-green-700"
        : booking.booking_status === "cancelled"
        ? "rounded-full bg-red-100 px-3 py-1 text-sm font-semibold text-red-700"
        : "rounded-full bg-yellow-100 px-3 py-1 text-sm font-semibold text-yellow-700"
    }
  >
    {
      booking.booking_status === "pending"
        ? "รอตรวจสอบ"
        : booking.booking_status === "confirmed"
        ? "ยืนยันแล้ว"
        : booking.booking_status === "cancelled"
        ? "ยกเลิก"
        : booking.booking_status
    }
  </span>

</td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}